---
title: Unendliches Schreiben
episode: 1.1
staffel: 1
description: Dere
date: 10/12/2024
photos: "./stern-pink.png"
---

# The Futile Corporation
### David Obradović

### 24.01. – 11.02.2024
In der ersten Episode schaltet J. Doe versehentlich einen Stift frei, der mit ununterbrochenem Schreiben und Singen durchdreht. Machen Sie sich auf ein urkomisches Durcheinander aus Symbolik und Chaos in diesem ernsthaft albernen Abenteuer gefasst!


### 24.01. – 31.01.
the Futile Corporation: Aliasing

Aliasing beschreibt visuelle Verzerrungen oder Artefakte, die auftreten, wenn ein digitales Signal unzureichend abgetastet oder angezeigt wird. Sowohl im Digitalen als auch in der materiellen Welt bezieht Aliasing sich auf unerwünschte Effekte. Ob im Raum digitaler Darstellungen, visueller Verschmutzung oder Umweltzerstörung, die Wahrnehmung unerwünschter Artefakte bleibt immer von den Betrachtenden abhängig.


### 01.02. – 11.02.
David Obradović: Unglaublich! Orthodoxe Ikonen brechen ihr Schweigen! 
 
David Obradovićs Installation beschäftigt sich mit der Macht des Glaubens und dessen Darstellung in der orthodoxen Kirche. Acht ausgewählte Ikonen übertragen das in Ton umgewandelte Licht von orthodoxen Kirchen. Die im Raum schwebenden Bilder formen eine ambisonische Kuppel um die Betrachter:in. Kommen Sie vorbei und lauschen Sie den erhellenden Klängen der heiligen Krieger!

